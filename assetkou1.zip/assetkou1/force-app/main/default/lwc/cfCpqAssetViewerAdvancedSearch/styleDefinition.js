let styleDefinition =
      {"state0element1":[{"conditions":"default","styleObject":{"class":"slds-col  condition-element  slds-size_12-of-12 ","style":"","styleProperties":""}}]};
  export default styleDefinition